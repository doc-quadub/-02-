package calculation;
import java.util.Scanner;

public class calc {
	
	public static void main(String[] args) {
		
		System.out.println("Введите операцию:");
		System.out.println("1 - Сложение");
		System.out.println("2 - Вычитание");
		System.out.println("3 - Умножение");
		System.out.println("4 - Деление");
		
		// Леонов Сергей Дмитриевич
		
		Scanner scanner = new Scanner(System.in);
		int operation = scanner.nextInt();
		
		System.out.print("Введите первое число: ");
		int x = scanner.nextInt();
		
		// Отступ
		System.out.println();
		
		System.out.print("Введите второе число: ");
		int y = scanner.nextInt();
		
		int answer = 0;
		if (operation == 1)
			answer = x + y;
		else if (operation == 2)
			answer = x - y;
		else if (operation == 3)
			answer = x * y;
		else if (operation == 4)
			answer = x / y;		
		System.out.println("Результат = " + answer);
		System.out.println("Леонов С. Д.");
	}
}
